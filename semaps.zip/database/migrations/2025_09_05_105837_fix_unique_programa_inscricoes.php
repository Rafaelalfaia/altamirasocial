<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // (0) Garante que dependente_id aceita NULL (para o titular).
        // Evita depender do doctrine/dbal.
        try {
            DB::statement("ALTER TABLE programa_inscricoes MODIFY dependente_id BIGINT UNSIGNED NULL");
        } catch (\Throwable $e) {
            // Se já for NULLABLE, ignore.
        }

        // (1) Drop do índice único antigo em (programa_id, cidadao_id)
        // Tentamos pelos dois jeitos (por colunas ou por nome do índice),
        // pois o nome pode variar.
        try {
            Schema::table('programa_inscricoes', function (Blueprint $table) {
                $table->dropUnique(['programa_id', 'cidadao_id']);
            });
        } catch (\Throwable $e) {
            try {
                Schema::table('programa_inscricoes', function (Blueprint $table) {
                    $table->dropUnique('programa_inscricoes_programa_id_cidadao_id_unique');
                });
            } catch (\Throwable $e2) {
                // Se não existir, seguimos adiante.
            }
        }

        // (2) Cria coluna gerada dep_guard = COALESCE(dependente_id, 0)
        // Tenta sintaxe do MySQL 8+; se falhar (MariaDB), usa PERSISTENT.
        try {
            DB::statement("
                ALTER TABLE programa_inscricoes
                ADD COLUMN dep_guard BIGINT UNSIGNED
                GENERATED ALWAYS AS (COALESCE(dependente_id, 0)) STORED
            ");
        } catch (\Throwable $e) {
            // MariaDB fallback
            DB::statement("
                ALTER TABLE programa_inscricoes
                ADD COLUMN dep_guard BIGINT
                AS (IFNULL(dependente_id, 0)) PERSISTENT
            ");
        }

        // (3) Índice único novo: (programa_id, cidadao_id, dep_guard)
        Schema::table('programa_inscricoes', function (Blueprint $table) {
            $table->unique(['programa_id', 'cidadao_id', 'dep_guard'], 'ux_prog_cid_dep_guard');
        });
    }

    public function down(): void
    {
        // Remove o índice novo
        try {
            Schema::table('programa_inscricoes', function (Blueprint $table) {
                $table->dropIndex('ux_prog_cid_dep_guard');
            });
        } catch (\Throwable $e) {
            // nome pode variar se o SGBD renomear — ignore
        }

        // Remove a coluna gerada
        try {
            Schema::table('programa_inscricoes', function (Blueprint $table) {
                $table->dropColumn('dep_guard');
            });
        } catch (\Throwable $e) {
            // ignore se já não existir
        }

        // Recria o índice antigo (programa_id, cidadao_id)
        Schema::table('programa_inscricoes', function (Blueprint $table) {
            $table->unique(['programa_id', 'cidadao_id'], 'programa_inscricoes_programa_id_cidadao_id_unique');
        });
    }
};
