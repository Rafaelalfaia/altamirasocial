<?php

namespace App\Http\Controllers\Assistente;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Cidadao;
use App\Models\Bairro;

class UsuarioController extends Controller
{

    public function index(Request $request)
    {

        $nome = $request->input('nome');
        $bairro_id = $request->input('bairro_id');

        $cidadaos = Cidadao::with(['bairro.cidade.estado', 'user', 'ultimoAcompanhamento.user'])
            ->when($nome, fn($q) => $q->where('nome', 'like', "%{$nome}%"))
            ->when($bairro_id, fn($q) => $q->where('bairro_id', $bairro_id))
            ->paginate(10);

        $bairros = Bairro::with('cidade')->orderBy('nome')->get();

        return view('assistente.usuarios.index', compact('cidadaos', 'bairros', 'nome', 'bairro_id'));
    }

    public function show($id)
    {
        $usuario = User::with('roles')->findOrFail($id);
        return view('assistente.usuarios.show', compact('usuario'));
    }


    public function editar($id)
    {
        $cidadao = Cidadao::with(['user', 'bairro.cidade.estado'])
            ->where('user_id', $id)
            ->firstOrFail();

        return view('cidadao.perfil.dados', compact('cidadao'));
    }
}
