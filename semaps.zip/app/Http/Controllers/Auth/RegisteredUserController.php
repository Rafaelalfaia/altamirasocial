<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Illuminate\View\View;

class RegisteredUserController extends Controller
{
    /**
     * Exibe a view de cadastro
     */
    public function create(): View
    {
        return view('auth.register');
    }

    /**
     * Armazena novo usuário após registro
     */
    public function store(Request $request): RedirectResponse
    {
        // Limpa o CPF removendo máscara (mantém apenas números)
        $cpf = preg_replace('/[^0-9]/', '', $request->cpf ?? '');

        // Reatribui o CPF limpo para a requisição
        $request->merge(['cpf' => $cpf]);

        // Validação com mensagens personalizadas
        $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'cpf' => ['required', 'digits:11', 'unique:users,cpf'],
            'email' => ['nullable', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
        ], [
            'cpf.required' => 'O campo CPF é obrigatório.',
            'cpf.digits' => 'O CPF deve conter exatamente 11 dígitos (sem pontos ou traços).',
            'cpf.unique' => 'Este CPF já está em uso.',
            'email.unique' => 'Este e-mail já está em uso.',
            'password.confirmed' => 'As senhas não coincidem.',
        ]);

        // Criação do usuário
        $user = User::create([
            'name' => $request->name,
            'cpf' => $cpf,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        // Atribui automaticamente o papel de Cidadão
        $user->assignRole('Cidadao');
        // Dispara evento e loga o usuário
        event(new Registered($user));
        Auth::login($user);

        // Redireciona para a home
        return redirect()->intended(RouteServiceProvider::HOME);
    }
}
